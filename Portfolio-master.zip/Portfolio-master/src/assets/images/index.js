export { default as Upwork } from './upwork.svg';
export { default as PeoplePerHour } from './peopleperhour.svg';
export { default as Freelancer } from './freelancer.svg';
export { default as Logo } from './logo.png';
export { default as Play } from './play.png';
export { default as Company } from './company.png';
