export { default as Hero } from '../components/Hero';
export { default as Content } from '../components/Content';
export { default as CTA } from '../components/CTA';
