module.exports = {
  globDirectory: './public/',
  globPatterns: ['**/*.{html,js}'],
  swDest: './public/sw.js',
  clientsClaim: true,
  skipWaiting: true
};
